package com.pten.rbms.repository;
import org.springframework.data.repository.CrudRepository;

import com.pten.rbms.model.Room;

public interface RoomRepository extends CrudRepository<Room, Integer> {

}
